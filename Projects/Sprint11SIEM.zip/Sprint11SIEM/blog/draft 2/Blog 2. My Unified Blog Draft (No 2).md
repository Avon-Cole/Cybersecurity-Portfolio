Title: Hunting the Invisibles 

**Overview**
I walk through how I tuned a baseline Wazuh SIEM deployment, added new log sources, and ran real-world attack simulations to see what defenders actually see during an incident. From tweaking Sysmon configs to watching Atomic Red Team activity light up my dashboards, this lab turned abstract security concepts into concrete, trackable evidence. 

**Introduction**
Cybersecurity fascinates me because it sits at the intersection of people, technology, and creativity. Attackers are constantly inventing new ways to bend systems to their will, and defenders have to think just as creatively to spot the smallest breadcrumbs in logs and telemetry. I love that this field rewards curiosity: every alert or odd log entry is a puzzle to unpack, and solving it can protect real people and organizations. As someone transitioning into a SOC role, I’m drawn to the idea that my technical skills can directly reduce risk, stop intrusions, and turn chaotic data into clear, actionable stories about what actually happened on a network.

**Setup**
I choose to add Windows Defender logs from the ad01 Windows endpoint to Wazuh SIEM and tune the existing Sysmon configuration. On the ad01 endpoint, open the Wazuh agent config file at `C:\Program Files (x86)\ossec-agent\ossec.conf`. Then I add a block inside the ossec_config section to collect Defender logs. Save and restart the Wazuh service. Next, I download the existing `sysmonconfig-export.xml` from ad01 and tune it to add filters for Event ID 1, Event ID 3, and Event ID 7 to avoid missing malware loaders. I then uninstalled Sysmon and reinstalled with `sysmon.exe -i sysmonconfig-export.xml -accepteula`, then verify with `sysmon.exe -c`. Finally, in the Wazuh dashboard, it confirms new Defender events and tuned Sysmon events flow in within 5 minutes; test by running a benign PowerShell script and checking for ProcessCreate logs. 

But, before the successful hits, I initially forgot to restart the Wazuh agent service after editing `ossec.conf`, so Defender logs didn’t start flowing despite the config update. Wazuh showed no new events for over 15 minutes, so I thought I did something wrong until I manually restarted with `net start OssecSvc`. This simple oversight delayed verification and highlighted why service restarts are non-negotiable after config changes in production-like setups.

**Experiment Time**
I ran Atomic Red Team T1550.002 (Pass the Hash) from ART Workstation targeting ad01. Results: Wazuh caught Sysmon net connects (Event ID 3) and logons (4624). Defender flagged the tool but didn’t block it. Good chain visibility. # Experiment #2 Ran SysmonSimulator on ad01 to compare event logging before and after Sysmon configuration tuning. Results: Tuned config reduced noise by 70%. Key events like ProcessCreate (ID 1), FileCreate (ID 11), and NetworkConnect (ID 3) showed up clearly with relevant fields. # Experiment #3 Created a test user account on ad01, added it to the Domain Admins group, and logged in as that user. Results: Wazuh logged Security Event IDs 4720 (user creation), 4732 (group membership), and 4624 (logon). Sysmon tracked associated processes like mmc.exe and powershell.exe. Established normal admin baseline.

**One Mistake During the Experiment** 
In Experiment #1, I ran the Atomic Red Team test without doing the cleanup step first. Leftover files from a prior run triggered extra Defender alerts that confused my results. I had to restart ad01 to clear it, wasting 15 minutes. Always run cleanup commands before tests!

**Summary and Results of Findings**
My experiments showed Wazuh catches real threats well when tuned right. Pass the Hash (Exp #1) triggered Sysmon network connects, logons, and Defender full attack chain visible. Sysmon tuning.
(Exp #2) cut log noise by 70% while keeping key events like process starts and file creates. Normal admin actions.
(Exp #3) gave a clean baseline of user/group changes and tool usage. Overall, Defender plus tuned Sysmon = strong detection combo for SOC work. Strong points: Real TTP testing proved the SIEM setup works for lateral movement and admin abuse. Weak point: Untuned Sysmon floods alerts; tuning is critical.

==ADVICE==
Always restart the Wazuh agent (`net stop OssecSvc` then `net start OssecSvc`) right after editing ossec.conf. I forgot once, and the Defender logs took 10+ minutes to appear. Add a checklist: Edit → Save → Restart → Verify in 5 mins. 2. Run Atomic Red Team’s `Invoke-AtomicRedTeam -Cleanup` before every test. Leftover files confused Defender in Exp #1, forcing a reboot and wasting time.

**Final Thoughts**
The coolest part was seeing a full attack chain light up in real-time. When I ran Pass the Hash, Wazuh showed the exact network connection from ART Workstation to ad01, the sneaky SYSTEM logon, and Defender’s PUA flag on the tool all correlated in one dashboard. It clicked for me: this is how SOC analysts actually catch live intrusions from noisy logs. 

One piece of advice take VM snapshots before every big change or test. If something breaks (like my forgotten cleanups or agent restarts), revert in seconds instead of rebooting everything. 

My favorite resource Olaf Hartong’s sysmon-modular GitHub repo. It breaks Sysmon config into mix-and-match blocks for your exact threat model. This is way easier than tweaking giant XML files blind. 

Lastly, Big thanks to the instructors for the hands-on Wazub labs. They made abstract ATT&CK techniques feel real and got me excited for the real world. Also, thank you to Zafer Balkan for his article “Fine-Tuning Sysmon Configuration for Wazuh.” It showed me exactly how to cut Sysmon noise while keeping the good events flowing into Wazuh, making my tuning way easier as a beginner.