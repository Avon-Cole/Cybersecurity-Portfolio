Title: Hunting the Invisibles 

**Overview**
I walk through how I tuned a baseline Wazuh SIEM deployment, added new log sources, and ran real-world attack simulations to see what defenders actually see during an incident. From tweaking Sysmon configs to watching Atomic Red Team activity light up my dashboards, this lab turned abstract security concepts into concrete, trackable evidence. 

**Introduction**
Cybersecurity fascinates me because it sits at the intersection of people, technology, and creativity. Attackers are constantly inventing new ways to bend systems to their will, and defenders have to think just as creatively to spot the smallest breadcrumbs in logs and telemetry. I love that this field rewards curiosity: every alert or odd log entry is a puzzle to unpack, and solving it can protect real people and organizations. As someone transitioning into a SOC role, I’m drawn to the idea that my technical skills can directly reduce risk, stop intrusions, and turn chaotic data into clear, actionable stories about what actually happened on a network.

**Setup**
I choose to add Windows Defender logs from the ad01 Windows endpoint to Wazuh SIEM and tune the existing Sysmon configuration. On the ad01 endpoint, open the Wazuh agent config file at `C:\Program Files (x86)\ossec-agent\ossec.conf`. Then I add a block inside the ossec_config section to collect Defender logs. Save and restart the Wazuh service. Next, I download the existing `sysmonconfig-export.xml` from ad01 and tune it to add filters for Event ID 1, Event ID 3, and Event ID 7 to avoid missing malware loaders. I then uninstalled Sysmon and reinstalled with `sysmon.exe -i sysmonconfig-export.xml -accepteula`, then verify with `sysmon.exe -c`. Finally, in the Wazuh dashboard, it confirms new Defender events and tuned Sysmon events flow in within 5 minutes; test by running a benign PowerShell script and checking for ProcessCreate logs. 

But, before the successful hits, I initially forgot to restart the Wazuh agent service after editing `ossec.conf`, so Defender logs didn’t start flowing despite the config update. Wazuh showed no new events for over 15 minutes, so I thought I did something wrong until I manually restarted with `net start OssecSvc`. This simple oversight delayed verification and highlighted why service restarts are non-negotiable after config changes in production-like setups.

**Experiment Time**
**Modification:**
1. Logged into ad01 

2. Edited Wazuh agent config (`C:\Program Files (x86)\ossec-agent\ossec.conf`):

<localfile> 
<location>Microsoft-Windows-Windows Defender/Operational</location>
  <log_format>eventchannel</log_format>
</localfile>


3. Restarted Wazuh agent:
![[Pasted image 20260220235127.png]]

4. Exported current Sysmon config: `sysmon.exe -c sysmonconfig-export.xml`

5. Tuned Sysmon config for less noise:
![[Pasted image 20260220235324.png]]

6. Reinstalled Sysmon:
![[Pasted image 20260220235431.png]]

7. Verified new Defender/Sysmon events in Wazuh dashboard (Agents → ad01)

What, How, Why?
•	What: Added Defender logs + tuned Sysmon filters
•	How: Used Wazuh’s built-in eventchannel decoder plus modified Neo23x0 Sysmon config
•	Why: Defender catches malware; untuned Sysmon floods alerts (70% noise reduction after tuning)

# Experiment 1

1. On ART Workstation: `git clone https://github.com/redcanaryco/atomic-red-team`

2. Ran test: 
Invoke-AtomicTest T1550.002 -TestNumbers 1 -ComputerName "ad01.lab.local"

Result: Wazuh caught Sysmon net connects (Event ID 3) and logons (4624). Defender flagged the tool but didn’t block it. Good chain visibility. 

![[IMG_1881.jpg]]
# Experiment #2
Used SysmonSimulator on ad01 before/after Sysmon tune. 

Before tuning: `SysmonSimulator.exe --all` → 1,247 events in 5 minutes
2.	Applied tuned config 
3.	After tuning: `SysmonSimulator.exe --all` → 389 events in 5 minutes

Results: Before tuning, noisy events flooded Wazuh. After, it focused on key stuff: Event ID 1 showed command lines clearly, Event ID 11 caught file creates with hashes and Event ID 3 listed IPs/ports. Noise dropped 70%, making real alerts easier to spot in the dashboard. Tuned config worked way better for clean logs.

Before Console Output: # On ad01 - original Sysmon config C:\SysmonSimulator\SysmonSimulator.exe --all
![[Pasted image 20260220233210.png]]Flood of 1,247 Sysmon events - mostly repetitive svchost.exe noise.

After Console Output: # Same command, new Sysmon config applied C:\SysmonSimulator\SysmonSimulator.exe --all

![[Pasted image 20260220233932.png]]
Only 389 Events.

Wazuh Output After tuning![[Pasted image 20260220234152.png]]

# Experiment #3
I logged into ad01 as admin, made a new user “testuser”, added it to Domain Admins, and logged in as that user once. Watched for normal admin logs in Wazuh.
 
 Results: Wazuh captured Security Event ID 4720 (testuser create), 4732 (added to group) and 4624 (logon) with SID details and timestamps. Sysmon logged Event ID 1 for mmc.exe and powershell.exe used, with full command lines. Defender had no alerts since it was benign. 

![[Pasted image 20260220234403.png]]

**One Mistake During the Experiment** 
In Experiment #1, I ran the Atomic Red Team test without doing the cleanup step first. Leftover files from a prior run triggered extra Defender alerts that confused my results. I had to restart ad01 to clear it, wasting 15 minutes. Always run cleanup commands before tests!

**Summary and Results of Findings**
My experiments showed Wazuh catches real threats well when tuned right. Pass the Hash (Exp #1) triggered Sysmon network connects, logons, and Defender full attack chain visible. Sysmon tuning.
(Exp #2) cut log noise by 70% while keeping key events like process starts and file creates. Normal admin actions.
(Exp #3) gave a clean baseline of user/group changes and tool usage. Overall, Defender plus tuned Sysmon = strong detection combo for SOC work. Strong points: Real TTP testing proved the SIEM setup works for lateral movement and admin abuse. Weak point: Untuned Sysmon floods alerts; tuning is critical.

==ADVICE==
Always restart the Wazuh agent (`net stop OssecSvc` then `net start OssecSvc`) right after editing ossec.conf. I forgot once, and the Defender logs took 10+ minutes to appear. Add a checklist: Edit → Save → Restart → Verify in 5 mins. 2. Run Atomic Red Team’s `Invoke-AtomicRedTeam -Cleanup` before every test. Leftover files confused Defender in Exp #1, forcing a reboot and wasting time.

**Final Thoughts**
The coolest part was seeing a full attack chain light up in real-time. When I ran Pass the Hash, Wazuh showed the exact network connection from ART Workstation to ad01, the sneaky SYSTEM logon, and Defender’s PUA flag on the tool all correlated in one dashboard. It clicked for me: this is how SOC analysts actually catch live intrusions from noisy logs. 

One piece of advice take VM snapshots before every big change or test. If something breaks (like my forgotten cleanups or agent restarts), revert in seconds instead of rebooting everything. 

My favorite resource Olaf Hartong’s sysmon-modular GitHub repo. It breaks Sysmon config into mix-and-match blocks for your exact threat model. This is way easier than tweaking giant XML files blind. 

Lastly, Big thanks to the instructors for the hands-on Wazub labs. They made abstract ATT&CK techniques feel real and got me excited for the real world. Also, thank you to Zafer Balkan for his article “Fine-Tuning Sysmon Configuration for Wazuh.” It showed me exactly how to cut Sysmon noise while keeping the good events flowing into Wazuh, making my tuning way easier as a beginner.