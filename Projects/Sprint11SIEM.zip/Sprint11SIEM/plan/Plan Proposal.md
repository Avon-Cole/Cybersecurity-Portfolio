
# Modifications to environment
### Modification #1
Add Windows defender logs from ad01 into Wazuh and tune Sysmon on ad01. 

#### References to use while implementing
- [x] ADD
Wazuh log collection for Windows Event Channels and supported providers.

Sysmon base config

# Experiments to run
### Experiment #1

Run Atomic red team test for lateral movement or credential access TTP. For example, a technique under MITRE’s lateral movement or credential access tactics against ad01 and observer plus Sysmon logs in Wazuh.

#### References to use while conducting
- [ ] ADD
- [ ] REFERENCE

Chosen Atomic Red Team technique documentation (MITRE ATT&CK mapping, commands, and cleanup steps)

Wazuh Windows log analysis documentation to interpret Defender and Sysmon events inside the SIEM.

Comment and examples inside `sysmonconfig-export.xml` to understand what each event filter is trying to capture


### Experiment #2

Use Sysmon on ad01 to generate a burst of synthetic Sysmon events and verify how tuned Sysmon config changes what appears in Wazuh.

#### References to use while conducting
- [ ] ADD
- [ ] REFERENCE

Wazuh Windows and Sysmon log collection guidance for event channel mapping and decoder behavior.

Sysmon usage instructions from its documentation to know which events it triggers.

### Experiment #3

Perform a benign but traceable admin activity on ad01. For example, creating a new user and adding it to a group and verifying the end‑to‑end visibility in Wazuh using Windows, Defender, and Sysmon logs.**

#### References to use while conducting
- [ ] ADD
- [ ] REFERENCE
Wazuh documentation on supported Windows Security and System event channels and how to configure them.

Sysmon base config notes describing which user and process activities should be logged and why.
Windows event ID references. For example, user creation and group membership changes to map what you see in Wazuh back to specific actions.
